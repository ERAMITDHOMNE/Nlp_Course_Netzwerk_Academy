# Sentiment Analysis

## This Project Implemented By Areej Nouh & Mohammad Darmousa 
